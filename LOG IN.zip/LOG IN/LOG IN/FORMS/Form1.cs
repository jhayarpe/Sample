﻿using LOG_IN.FORMS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LOG_IN
{
    public partial class Form1 : Form
    {

        private SqlConnection conn;

        public Form1()
        {
            InitializeComponent();
            conn = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=PREEZ;Integrated Security=True");
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Register register = new Register();
            register.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "")
            {
                MessageBox.Show("Enter the username", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("Enter the password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("select * from userAccount where userName = @username and [Password] = @password", conn);
                    cmd.Parameters.AddWithValue("username", txtUsername.Text);
                    cmd.Parameters.AddWithValue("password", txtPassword.Text);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        string userType = dt.Rows[0]["userType"].ToString();

                        if (userType.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                        {
                            var teacherDashboard = new Frm_Admin_Dashboard();
                            teacherDashboard.ShowDialog();
                        }
                        else if (userType.Equals("Customer", StringComparison.OrdinalIgnoreCase))
                        {
                            var studentDashboard = new Frm_Customer_Dashboard();
                            studentDashboard.ShowDialog();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password");
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Please connect to database", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            txtPassword.Clear();
        }
    }
    
}
