﻿using LOG_IN.FORMS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LOG_IN
{
    public partial class Register : Form
    {
        private SqlConnection conn;
        public Register()
        {
            InitializeComponent();
            conn = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=PREEZ;Integrated Security=True");
        }

        private void lblLogin_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            login.Show();
            this.Hide();
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "")
            {
                MessageBox.Show("Enter the Username", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("Enter the Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtConfirmPassword.Text == "")
            {
                MessageBox.Show("Enter the Confirm Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("Insert * from userAccount where userName = @username and [Password] = @password and ConfirmPassword = @ConfirmPassword and userType = @userType", conn);
                    cmd.Parameters.AddWithValue("username", txtUsername.Text);
                    cmd.Parameters.AddWithValue("password", txtPassword.Text);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        string userType = dt.Rows[0]["userType"].ToString();

                        if (userType.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                        {
                            var teacherDashboard = new Frm_Admin_Dashboard();
                            teacherDashboard.ShowDialog();
                        }
                        else if (userType.Equals("Customer", StringComparison.OrdinalIgnoreCase))
                        {
                            var studentDashboard = new Frm_Customer_Dashboard();
                            studentDashboard.ShowDialog();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password");
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Please connect to database", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Register_Load(object sender, EventArgs e)
        {

        }
    }
}
