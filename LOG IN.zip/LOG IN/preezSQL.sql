CREATE DATABASE PREEZ

use PREEZ

CREATE TABLE userAccount
(
	userId int IDENTITY (1,1) PRIMARY KEY,
	userName varchar (50),
	[Password] varchar (50),
	ConfirmPassword varchar (50),
	userType varchar (50)
)


INSERT INTO userAccount(userName, [Password], userType)
	VALUES('juje', 'jujeGwapo', 'Customer')


DROP TABLE userAccount
SELECT * FROM userAccount